<?php

include_once "../model/m_user.php";

$db = new user();
$data = $db->get_data('user');


if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $handler = new user();
    
    // Ambil data dari $_POST
    $username = $_POST['username'];
    $email = $_POST['email'];
    $pass = $_POST['pass'];
    $nama = $_POST['nama']; 
    $alamat = $_POST['alamat'];
    $jk = $_POST['jk'];
    $tempat_lahir = $_POST['tempat_lahir'];
    $tanggal_lahir = $_POST['tanggal_lahir'];

    $handler->add_user($username, $email, $pass, $nama, $alamat, $jk, $tempat_lahir, $tanggal_lahir);
}


?>