<?php
include_once '../controller/c_connection.php';

class user {

    private $dbconn;

    //koneksi
    public function __construct() {
        $database = new connUser();
        $this->dbconn = $database->connect();
    }

    function get_data($user) {
        $sql = "SELECT * FROM $user";
        $query = mysqli_query($this->dbconn, $sql); 
    
        
        if (!$query) {
            die("Query fail: " . mysqli_error($this->dbconn)); 
        }
    
        $data = [];
        while ($row = mysqli_fetch_assoc($query)) {
            $data[] = $row;
        }
    
        return $data;
    }
    
    function get_data_byId($user, $id) {
        $sql = "SELECT * FROM $user WHERE id_user= $id";
        $query = mysqli_query($this->dbconn, $sql); 
    
        
        if (!$query) {
            die("Query fail: " . mysqli_error($this->dbconn)); 
        }
    
        $data = [];
        while ($row = mysqli_fetch_assoc($query)) {
            $data[] = $row;
        }
    
        return $data;
    }

    function add_user($username, $email, $pass, $nama, $alamat, $jk, $tempat_lahir, $tanggal_lahir) {
        $sql = "INSERT INTO user (username, email, password, nama_user, alamat_user, jenis_kelamin, tempatlahir_user, tanggallahir_user) 
        VALUES ('$username', '$email', '$pass', '$nama', '$alamat', '$jk', '$tempat_lahir', '$tanggal_lahir')";
        $query = mysqli_query($this->dbconn, $sql);

        if (!$query) {
            die("Error pada query add_user: " . mysqli_error($this->dbconn));
        }

        if ($query) {
            echo "<script>alert('Data berhasil ditambahkan'); window.location='../view/tugas1.php';</script>";
        } else {
            echo "<script>alert('Gagal menambahkan data. Silakan cek log error.'); window.location='../views/form.php';</script>";
        }
    }

}
?>
