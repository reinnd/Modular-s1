<?php

include "template/head.php";
?>
<title>Kelompok</title>
<link rel="stylesheet" href="style/nord.css?v=1.1">
<link rel="stylesheet" href="style/style.css?v=1.1">

<?php
include "template/navbar.php";
?>

<br><br><br>
<h1>TUGAS KONSENTRASI KEAHLIAN REKAYASA PERANGKAT LUNAK
    <br>
    KELAS 11 RPL 2
</h1>
<br><br><br><br>
<div class="just-box">
    <h2>Anggota Kelompok</h2>
    <br>
        <ul class="ol-box">
            <li class="k-c">M. Pandji Hutama</li>
            <li class="k-c">Putra Rizkykha Masayu</li>
        </ul>
</div>

<?php

include "template/footer.php";
?>